# College Parking Website Backend
from flask import Flask, request, render_template, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from datetime import datetime
import os

# Initialize the Flask application with a college parking theme
college_parking = Flask(__name__)
college_parking.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'your-secret-key')
college_parking.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///parking.db'
college_parking.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(college_parking)
bcrypt = Bcrypt(college_parking)

# Database Models
default_reg = lambda: datetime.utcnow()
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    user_type = db.Column(db.String(20), nullable=False)  # 'student' or 'faculty'
    staff_id = db.Column(db.String(50), nullable=True)
    reg_number = db.Column(db.String(50), nullable=True)
    vehicles = db.relationship('Vehicle', backref='owner', lazy=True)

class Vehicle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    vehicle_number = db.Column(db.String(50), nullable=False)
    vehicle_type = db.Column(db.String(20), nullable=False)  # 'two-wheeler' or 'four-wheeler'
    registered_at = db.Column(db.DateTime, default=default_reg)

class ParkingSlot(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    slot_type = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(20), nullable=False, default='Available')
    current_user = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    slot_id = db.Column(db.Integer, db.ForeignKey('parking_slot.id'), nullable=False)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'), nullable=False)
    time_from = db.Column(db.DateTime, nullable=False)
    time_to = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), nullable=False, default='Active')

# Routes
@college_parking.route('/')
def home():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@college_parking.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        data = request.form
        hashed_pw = bcrypt.generate_password_hash(data['password']).decode('utf-8')
        user = User(
            email=data['email'], password=hashed_pw,
            first_name=data['first_name'], last_name=data['last_name'],
            user_type=data['user_type'],
            staff_id=data.get('staff_id'), reg_number=data.get('reg_number')
        )
        db.session.add(user)
        db.session.commit()
        # Register vehicle immediately
        vehicle = Vehicle(
            user_id=user.id,
            vehicle_number=data['vehicle_number'],
            vehicle_type=data['vehicle_type']
        )
        db.session.add(vehicle)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('signup.html')

@college_parking.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.form
        user = User.query.filter_by(email=data['email']).first()
        if user and bcrypt.check_password_hash(user.password, data['password']):
            session['user_id'] = user.id
            return redirect(url_for('dashboard'))
    return render_template('login.html')

@college_parking.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    slots = ParkingSlot.query.all()
    vehicles = Vehicle.query.filter_by(user_id=session['user_id']).all()
    return render_template('dashboard.html', slots=slots, vehicles=vehicles)

@college_parking.route('/book', methods=['POST'])
def book_parking():
    data = request.form
    booking = Booking(
        user_id=session['user_id'],
        slot_id=int(data['slot_id']),
        vehicle_id=int(data['vehicle_id']),
        time_from=datetime.strptime(data['time_from'], '%Y-%m-%dT%H:%M'),
        time_to=datetime.strptime(data['time_to'], '%Y-%m-%dT%H:%M')
    )
    slot = ParkingSlot.query.get(booking.slot_id)
    slot.status = 'Booked'
    slot.current_user = session['user_id']
    db.session.add(booking)
    db.session.commit()
    return redirect(url_for('dashboard'))

@college_parking.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    db.create_all()
    # Initialize 500 slots if none exist
    if ParkingSlot.query.count() == 0:
        for i in range(1, 501):
            slot_type = 'two-wheeler' if i <= 250 else 'four-wheeler'
            db.session.add(ParkingSlot(id=i, slot_type=slot_type))
        db.session.commit()
    college_parking.run(debug=True)